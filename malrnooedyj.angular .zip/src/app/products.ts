export const products = [
  {
    name: 'Dell',
    price: 40000,
    description: 'Dell is a US multinational computer technology company that develops, sells, repairs, and supports computers and related products and services. Named after its founder, Michael Dell, the company is one of the largest technological corporations in the world, employing more than 145,000 people in the U.'
  },
  {
    name: 'Apple',
    price: 699000,
    description: 'A great laptop with great price'
  },
  {
    name: 'Lenovo',
    price: 29999,
    description: 'Less price good laptop'
  }
];


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/